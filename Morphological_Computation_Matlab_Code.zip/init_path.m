disp('adding necessary paths')
% adapt this to your local paths
% this allows Matlab to find the used functions
addpath('/Users/hauser/Matlab/Morphological_Computation_Tutorial');
addpath('/Users/hauser/Matlab/Morphological_Computation_Tutorial/helping_functions');
addpath('/Users/hauser/Matlab/Morphological_Computation_Tutorial/data_vanderPol');
addpath('/Users/hauser/Matlab/Morphological_Computation_Tutorial/data_Volterra');
addpath('/Users/hauser/Matlab/Morphological_Computation_Tutorial/data_quad');
addpath('/Users/hauser/Matlab/Morphological_Computation_Tutorial/data_NARMA');